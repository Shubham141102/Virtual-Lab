var canvas = document.getElementById("mycanvas");
if (canvas.getContext){
   var ctx = canvas.getContext('2d');

   // drawing code here
   } else {

   // canvas-unsupported code here
}