# Searching_Visualizer

## Gifs

### Linear Search
![](./assets/gifs/linearSearch.gif)

### Binary Search
![](./assets/gifs/binarySearch.gif)

### [Live Demo](https://khageshwor.github.io/Searching_Visualizer/)

## Author

* **Khageshwor Joshi** - [Orion](https://github.com/khageshwor)

## Contributions of any kind  are welcome!

    - Leave a pull request!!! and dont forget to give a star.
